./ajouter 3 08:00 09:30 19 17 12 TP
./ajouter 3 09:30 11:00 19 17 12 TP
./ajouter 3 11:00 12:30 9 17 13 TP
./ajouter 3 17:00 18:30 9 3 13 TP
./ajouter 5 08:00 09:30 17 13 5 TP
./ajouter 5 09:30 11:00 24 13 0 TP
./ajouter 5 14:00 15:30 19 5 14 TP
./ajouter 5 15:30 17:00 19 5 14 TP
