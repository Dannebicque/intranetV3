./ajouter 2 14:00 15:30 24 13 0 TP
./ajouter 5 09:30 11:00 18 4 13 TP
./ajouter 5 11:00 12:30 18 4 13 TP
