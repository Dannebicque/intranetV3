./ajouter 1 08:00 09:30 0 18 2 CM
./ajouter 1 09:30 11:00 17 18 5 CM
./ajouter 1 11:00 12:30 13 18 4 CM
./ajouter 2 08:00 09:30 22 18 15 CM
./ajouter 2 09:30 11:00 9 18 3 CM
