./ajouter 1 14:00 15:30 13 25 4 TD
./ajouter 1 15:30 17:00 23 25 14 TD
./ajouter 1 17:00 18:30 3 25 9 TD
./ajouter 2 15:30 17:00 6 30 13 TD
./ajouter 2 17:00 18:30 15 30 9 TD
./ajouter 3 11:00 12:30 14 32 6 TD
./ajouter 4 11:00 12:30 14 19 6 TD
