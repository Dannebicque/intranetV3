./ajouter 3 08:00 09:30 6 4 13 TP
./ajouter 3 09:30 11:00 6 4 13 TP
./ajouter 5 09:30 11:00 17 14 5 TP
./ajouter 5 11:00 12:30 24 14 0 TP
./ajouter 5 14:00 15:30 23 16 14 TP
./ajouter 5 15:30 17:00 23 16 14 TP
