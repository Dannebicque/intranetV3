./ajouter 2 15:30 17:00 12 17 12 TP
./ajouter 2 17:00 18:30 12 17 12 TP
./ajouter 3 14:00 15:30 18 5 13 TP
./ajouter 3 17:00 18:30 18 5 13 TP
./ajouter 5 09:30 11:00 16 3 14 TP
./ajouter 5 11:00 12:30 16 3 14 TP
./ajouter 5 14:00 15:30 17 15 5 TP
./ajouter 5 15:30 17:00 24 15 0 TP
