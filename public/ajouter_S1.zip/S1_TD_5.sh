./ajouter 1 14:00 15:30 3 26 9 TD
./ajouter 1 15:30 17:00 13 26 4 TD
./ajouter 1 17:00 18:30 16 26 14 TD
./ajouter 2 14:00 15:30 18 29 13 TD
./ajouter 3 11:00 12:30 14 31 6 TD
