./ajouter 3 14:00 15:30 6 4 13 TP
./ajouter 3 17:00 18:30 6 4 13 TP
./ajouter 5 08:00 09:30 24 16 0 TP
./ajouter 5 09:30 11:00 23 16 14 TP
./ajouter 5 11:00 12:30 23 16 14 TP
./ajouter 5 15:30 17:00 17 13 5 TP
