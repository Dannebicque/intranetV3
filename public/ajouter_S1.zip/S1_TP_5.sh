./ajouter 3 08:00 09:30 18 5 13 TP
./ajouter 3 09:30 11:00 18 5 13 TP
./ajouter 4 08:00 09:30 24 16 0 TP
./ajouter 5 11:00 12:30 17 12 5 TP
./ajouter 5 14:00 15:30 16 3 14 TP
./ajouter 5 15:30 17:00 16 3 14 TP
