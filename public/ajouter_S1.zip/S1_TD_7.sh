./ajouter 1 14:00 15:30 14 27 6 TD
./ajouter 1 15:30 17:00 14 27 6 TD
./ajouter 1 17:00 18:30 18 27 13 TD
./ajouter 3 15:30 17:00 3 33 9 TD
./ajouter 3 17:00 18:30 13 33 4 TD
