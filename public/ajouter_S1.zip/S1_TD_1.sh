./ajouter 1 14:00 15:30 19 24 14 TD
./ajouter 1 15:30 17:00 3 24 9 TD
./ajouter 1 17:00 18:30 13 24 4 TD
./ajouter 2 14:00 15:30 9 28 13 TD
./ajouter 2 15:30 17:00 15 28 9 TD
./ajouter 2 17:00 18:30 14 28 6 TD
./ajouter 4 11:00 12:30 14 18 6 TD
